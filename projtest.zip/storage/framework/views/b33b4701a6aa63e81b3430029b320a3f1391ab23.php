<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <img src="/uploads/images/<?php echo e($user->profile_image); ?>" alt="">
                        Welcome <?php echo e($user->name); ?>

                        <div class="pull-right" data-friendid="<?php echo e($user->id); ?>">
                            <?php if(Auth::check()): ?>
                                <?php
                                    $i = Auth::user()->friends()->count();
                                    $c = 1;
                                ?>
                                <?php $__currentLoopData = Auth::user()->friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($user_1->user2->id == $user->id): ?>
                                        <a href="#" class="btn btn-link remove-friend">Remove Friend</a>
                                        <?php break; ?>
                                    <?php elseif($i == $c): ?>
                                        <a href="#" class="btn btn-link friend">Add Friend</a>
                                    <?php endif; ?>
                                    <?php
                                        $c++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($i == 0): ?>
                                    <a href="#" class="btn btn-link friend">Add Friend</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <a href="<?php echo e(route('friend.show', $user->id)); ?>" class="btn btn-link">View Friends</a>
                        </div>
                    </h3>
                </div>
                <div class="panel-body">
                    <div>
                      <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#posts" aria-controls="posts" role="tab" data-toggle="tab">Your Posts</a></li>
                        <li role="presentation"><a href="#comments" aria-controls="comments" role="tab" data-toggle="tab">Comments</a></li>
                        <li role="presentation"><a href="#likes" aria-controls="likes" role="tab" data-toggle="tab">Liked Posts</a></li>
                      </ul>
                      <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active fade in" id="posts">
                            <?php echo e($user->posts()->count()); ?> Posts created
                            <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="panel panel-default">
                                  <div class="panel-heading">
                                    <h3 class="panel-title">
                                        
                                        <div class="pull-right">
                                            <div class="dropdown">
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                                    <span class="caret"></span>
                                                </a>

                                                <ul class="dropdown-menu" role="menu">
                                                    <li><a href="<?php echo e(route('post.show', [$post->id])); ?>">Show Post</a></li>
                                                    <li><a href="<?php echo e(route('post.edit', [$post->id])); ?>">Edit Post</a></li>
                                                    <li>
                                                        <a href="#" onclick="document.getElementById('delete').submit()">Delete Post</a>
                                                        <?php echo Form::open(['method' => 'DELETE', 'id' => 'delete', 'route' => ['post.delete', $post->id]]); ?>

                                                        <?php echo Form::close(); ?>

                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </h3>
                                  </div>
                                  <div class="panel-body">
                                    <?php echo e($post->body); ?>

                                    <br />
                                    Category: <div class="badge"><?php echo e($post->category['name']); ?></div>
                                  </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="comments">
                            <?php echo e($user->comments()->count()); ?> Comments created
                            <?php $__currentLoopData = $user->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="panel panel-default">
                                  <div class="panel-body">
                                    <div class="col-sm-9">
                                        <?php echo e($comment->comment); ?>

                                    </div>
                                    <div class="col-sm-3">
                                        <small><a href="<?php echo e(route('post.show', [$comment->post->id])); ?>">View Post</a></small>
                                    </div>
                                  </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        <div role="tabpanel" class="tab-pane fade" id="likes">
                            <?php $__currentLoopData = $user->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($like->like): ?>
                                <?php if($like->post): ?>
                                    <div class="panel panel-default">
                                      <div class="panel-heading">
                                        <h3 class="panel-title">
                                            Created by <?php echo e($like->post->user->name); ?>

                                            <div class="pull-right">
                                                <div class="dropdown">
                                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                                        <span class="caret"></span>
                                                    </a>

                                                    <ul class="dropdown-menu" role="menu">
                                                        <li><a href="<?php echo e(route('post.show', [$like->post? $like->post->id : ''])); ?>">Show Post</a></li>
                                                        <li><a href="<?php echo e(route('post.edit', [$like->post ? $like->post->id : ''])); ?>">Edit Post</a></li>
                                                        <li>
                                                            <a href="#" onclick="document.getElementById('delete').submit()">Delete Post</a>
                                                            <?php echo Form::open(['method' => 'DELETE', 'id' => 'delete', 'route' => ['post.delete', $like->post->id]]); ?>

                                                            <?php echo Form::close(); ?>

                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </h3>
                                      </div>
                                      <div class="panel-body">
                                        <?php echo e($like->post->body); ?>

                                        <?php if($like->post->image != null): ?>
                                            <img src="/images/<?php echo e($like->post->image); ?>" alt="Image" width="100%" height="600">
                                        <?php endif; ?>
                                        <br />
                                        Category: <div class="badge"><?php echo e($like->post->category->name); ?></div>
                                      </div>
                                      <div class="panel-footer" data-postid="<?php echo e($like->post->id); ?>">
                                        <a href="#" class="btn btn-link like active-like">Like</a>
                                        <a href="#" class="btn btn-link like">Dislike</a>
                                         <a href="<?php echo e(route('post.show', [$like->post->id])); ?>" class="btn btn-link">Comment</a>
                                      </div>
                                    </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                      </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>