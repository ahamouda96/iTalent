<?php $__env->startSection('content'); ?>
<h1>Create post</h1>
	
		<?php echo Form::open(['method'=>'POST','action'=>'admin\AdminPostsController@store','files'=>true]); ?>

			
			<div class='form-group'>
		        <?php echo Form::label('body','Body:'); ?>

		        <?php echo Form::textarea('body',null,['class'=>'form-control', 'rows'=>5]); ?>

		    </div>

			<div class='form-group'>
		        <?php echo Form::label('media','media:'); ?>

		        <?php echo Form::file('media',null,['class'=>'form-control']); ?>

		    </div>

			<div class='form-group'>
		        <?php echo Form::label('category_id','Category:'); ?>

		        <?php echo Form::select('category_id',[''=>'Choose Category']+$categories,null,['class'=>'form-control']); ?>

		    </div>
			
		    <div class='form-group'>
		        <?php echo Form::submit('Create Post',['class'=>'btn btn-primary']); ?>

		    </div>

		<?php echo Form::close(); ?>


    <div class="row">
		<?php echo $__env->make('includes.form_error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>