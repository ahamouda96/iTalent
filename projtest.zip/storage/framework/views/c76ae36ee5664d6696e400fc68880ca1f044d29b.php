<?php $__env->startPush('css'); ?>
    <style>
        .favorite_posts{
            color: #E0245E;
        }
        .show-post{
            margin-top: 5%;
        }
        .pull-right{
            margin-top: -40px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="show-post col-sm-6 col-sm-offset-3">
            <div class="panel panel-default" style="margin: 0; border-radius: 0;">
            <div class="panel-heading">
            <h3 class="panel-title">  
                <img src="/uploads/images/<?php echo e($post->user->profile_image); ?>" alt="user image" style="width:40px; height:40px;border-radius: 50%;">
                <a href="<?php echo e(route('front.profile', ['id'=>$post->user->id])); ?>" style="text-decoration: none; color: #666">
                <span style="margin-left: 5px; font-weight: 600"><?php echo e($post->user->name); ?></span> <br>
                </a> 
                <span style="margin-left: 45px;"><?php echo e($post->updated_at->diffForHumans()); ?></span> 
            </h3>
                <h3 class="panel-title">
                    <?php if($post->friends()->count() > 0): ?>
                        <small>
                            with
                            <?php $__currentLoopData = $post->friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($tag->user2->name); ?>,
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </small>
                    <?php endif; ?>
                    
                    <div class="pull-right">
                        <a href="<?php echo e(url('/posts')); ?>">Return back</a>
                    </div>
                </h3>
              </div>
              <div class="panel-body">
                <?php echo e($post->body); ?>

                <?php if($post->postMedia): ?>
                    <?php if($post->postMedia->type=="image"): ?>
                    <img src="/uploads/posts/images/<?php echo e($post->postMedia->path); ?>" style='width:100%;height:600px;'>
                    <?php endif; ?>
                    <?php if($post->postMedia->type=="video"): ?>
                    <video style='width:100%;height:600px;' controls>
                        <source src="/uploads/posts/video/<?php echo e($post->postMedia->path); ?>">
                    </video>
                    <!-- <video src="/uploads/posts/video/<?php echo e($post->postMedia->path); ?>" controls style='width:250px;height:250px;'> -->
                    <?php endif; ?>
                <?php endif; ?>
                <br />
                <a href="<?php echo e(route('category.showAll', [$post->category->name])); ?>" class="badge"><?php echo e($post->category->name); ?></a>
              </div>
              <div class="panel-footer" data-postid="<?php echo e($post->id); ?>">
              <?php if(Auth::check()): ?>
                      <?php
                          $i = Auth::user()->likes()->count();
                          $commentCount = $post->comments()->where('comment', '!=', null)->count();
                      ?>
            
                <!-- like here-->
                <?php if(auth()->guard()->guest()): ?>
                <a href="javascript:void(0);" onclick="('To add favorite list. You need to login first.','Info',{
                    closeButton: true,
                    progressBar: true,
                    })">
                <i class="fa fa-heart"></i>
                <?php echo e($post->favorite_to_users->count()); ?>

                </a>
                <?php else: ?>
                    <a href="javascript:void(0);" onclick="document.getElementById('favorite-form-<?php echo e($post->id); ?>').submit();"
                        class="<?php echo e(!Auth::user()->favorite_posts->where('pivot.post_id',$post->id)->count()  == 0 ? 'favorite_posts' : ''); ?>">
                        <i class="fa fa-heart"></i>
                        <?php echo e($post->favorite_to_users->count()); ?>

                    </a>

                    <form id="favorite-form-<?php echo e($post->id); ?>" method="POST" action="<?php echo e(route('post.favorite',$post->id)); ?>" style="display: none;">
                    <?php echo csrf_field(); ?>
                    </form>
                <?php endif; ?>
                <?php endif; ?>
                <!-- end like here-->
                  <a href="#" class="btn btn-link">Comment</a>
              </div>
            </div>
            <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel panel-default" style="margin: 0; border-radius: 0;">
                  <div class="panel-body">
                      <div class="col-sm-9">
                          <?php echo e($comment->comment); ?>

                      </div>
                      <div class="col-sm-3 text-right">
                          <small>Commented by <?php echo e($comment->user->name); ?></small>
                      </div>
                  </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(Auth::check()): ?>
                <div class="panel panel-default" style="margin: 0; border-radius: 0;">
                  <div class="panel-body">
                      <form action="<?php echo e(url('/comment')); ?>" method="POST" style="display: flex;">
                          <?php echo e(csrf_field()); ?>

                          <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                          <input type="text" name="comment" placeholder="Enter your Comment" class="form-control" style="border-radius: 0;">
                          <input type="submit" value="Comment" class="btn btn-primary" style="border-radius: 0;">
                      </form>
                      <?php if(count($errors) > 0): ?>
                          <div class="alert alert-danger">
                              <a href="#" class="close" data-dismiss="alert">&times;</a>
                              <ul>
                                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php echo e($error); ?>

                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                          </div>
                      <?php endif; ?>
                      <?php if(Session::has('success')): ?>
                          <div class="alert alert-success">
                              <a href="#" class="close" data-dismiss="alert">&times;</a>
                              <?php echo e(Session::get('success')); ?>

                          </div>
                      <?php endif; ?>
                  </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>