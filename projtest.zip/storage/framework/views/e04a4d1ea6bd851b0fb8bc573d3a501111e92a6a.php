<?php $__env->startSection('content'); ?>

  <?php if(Session::has('deleted_user')): ?>
  <p class="bg-danger"><?php echo e(session('deleted_user').' has been deleted.'); ?></p>

    <!-- <p class="bg-danger"><?php echo e(session('deleted_user')); ?></p> -->
  <?php endif; ?>
    	<h1>Users</h1>

<table class="table">
  <thead>
    <tr>
      <th>Id</th>
      <th>Name</th>
      <th>Email</th>
      <th>Role</th>
      <th>photo</th>
      <th>Created</th>
      <th>Updated</th>
      <th>Edit</th>
      <th>Delete</th>
    </tr>
  </thead>
  <tbody>

  <?php if($users): ?>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
          <th><?php echo e($user->id); ?></th>
          <td><a href="<?php echo e(route('users.edit', $user->id)); ?>"><?php echo e($user->name); ?></a></td>
          <td><?php echo e($user->email); ?></td>
          <td><?php echo e($user->role_id == NULL ? 'User has no role' : $user->role->name); ?></td>
          <td><img height="30px" src="/uploads/images/<?php echo e($user->profile_image ? $user->profile_image : 'default.png'); ?>"></td>
          <td><?php echo e($user->created_at->diffForHumans()); ?></td>
          <td><?php echo e($user->updated_at->diffForHumans()); ?></td>
          <td>
            <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-success" style="text-decoration:none; color:#fff ">Edit</a>
          </td>
          <td>
			  		<?php echo Form::open(['method'=>'DELETE','action'=>['admin\AdminUsersController@destroy',$user->id]]); ?>

						<?php echo Form::submit('Delete',['class'=>'btn btn-danger']); ?>

					  <?php echo Form::close(); ?>

				</td>
        
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
    
  </tbody>
</table>
<div class="row">
		<div class="col-sm-6 col-sm-offset-5">
				<?php echo e($users->render()); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>