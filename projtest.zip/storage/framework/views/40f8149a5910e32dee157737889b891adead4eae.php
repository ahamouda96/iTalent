<?php $__env->startPush('css'); ?>
    <style>
        .favorite_posts{
            color: #E0245E;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<div class="contant">
  <div class="center">
    <div class="body">
       
      <?php echo $__env->make('posts.leftaside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- start posts-->
<div class="col-sm-6">
<?php if(Session::has('success')): ?>
<div class="alert alert-success">
<a href="#" class="close" data-dismiss="alert">&times;</a>
<?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>


<!-- Start Section Posts -->
<div class="posts current-post"> 
<!-- Start Create Poste -->
<?php echo $__env->make('posts.create', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><!--start foreach loop posts-->

<div class="post">

<?php if(request()->has('search')&& request()->get('search') != ''): ?>
you are search on <?php echo e(request()->get('search')); ?>

<?php endif; ?>

<div class="post-icon">
<?php if(Auth::check()): ?>
<?php
  $i = Auth::user()->likes()->count();
  $commentCount = $post->comments()->where('comment', '!=', null)->count();
  ?>
<?php if(auth()->guard()->guest()): ?>
<a href="javascript:void(0);" onclick="('To add favorite list. You need to login first.','Info',{
    closeButton: true,
    progressBar: true,
    })">
  <i class="fa fa-heart"></i>
  <?php echo e($post->favorite_to_users->count()); ?>

</a>
<?php else: ?>
    <a href="javascript:void(0);" onclick="document.getElementById('favorite-form-<?php echo e($post->id); ?>').submit();"
        class="<?php echo e(!Auth::user()->favorite_posts->where('pivot.post_id',$post->id)->count()  == 0 ? 'favorite_posts' : ''); ?>">
        <i class="fa fa-heart"></i>
        <?php echo e($post->favorite_to_users->count()); ?>

      </a>

    <form id="favorite-form-<?php echo e($post->id); ?>" method="POST" action="<?php echo e(route('post.favorite',$post->id)); ?>" style="display: none;">
    <?php echo csrf_field(); ?>
    </form>
<?php endif; ?>
<?php endif; ?>
    <i class="fa fa-comment"></i><h5><?php echo e($commentCount); ?></h5>
</div>

<!-- post-data-->

<div class="post-head">
<div class="post-info">
<img src="/uploads/images/<?php echo e($post->user->profile_image); ?>" alt="profile user image">
<div class="post-info-name">
<span class="name">

<a href="<?php echo e(route('front.profile', ['id' => $post->user->id])); ?>" style="text-decoration: none;color: #666;">
<?php echo e($post->user->name); ?>

</a>

</span>
<span class="time">
<?php echo e($post->updated_at->diffForHumans()); ?> </span>
</div>
</div>

<?php if(Auth()->user()->id == $post->user->id): ?> <!--check authentication to edit or delete posts-->
<ul class="my-dropdown">
<li class="dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
<span class="title-icon">
<span></span>
<span></span>
<span></span>
</span>
</a>

<ul class="dropdown-menu dropdown-menu-right">
<li><a href="<?php echo e(route('post.show', [$post->id])); ?>">Show Post</a></li>
<li><a href="<?php echo e(route('post.edit', [$post->id])); ?>">Edit Post</a></li>
<li>
<a href="#" onclick="document.getElementById('delete').submit()">Delete Post</a>
<?php echo Form::open(['method' => 'DELETE', 'id' => 'delete', 'route' => ['post.delete', $post->id]]); ?>

<?php echo Form::close(); ?>

</li>
</ul>
</li>
</ul>
<?php endif; ?> <!--end check authentication to edit or delete posts-->
</div>

<div class="post-content">
<p><?php echo e($post->body); ?></p>
<?php if($post->postMedia): ?>
<?php if($post->postMedia->type=="image"): ?>
<img src="/uploads/posts/images/<?php echo e($post->postMedia->path); ?>" style='width:100%;height:600px;'>
<?php endif; ?>
<?php if($post->postMedia->type=="video"): ?>
<video style='width:100%;height:600px;' controls>
    <source src="/uploads/posts/video/<?php echo e($post->postMedia->path); ?>">
</video>
<!-- <video src="/uploads/posts/video/<?php echo e($post->postMedia->path); ?>" controls style='width:250px;height:250px;'> -->
<?php endif; ?>
<br>
<?php endif; ?>
<a href="<?php echo e(route('category.showAll', [$post->category? $post->category->name : 'uncategoeized'])); ?>" class="badge"><?php echo e($post->category->name); ?></a>
</div>

<!-- post interacts-->


<!-- post interacts-->


<div class="post-footer">
</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- end foreach loop for posts -->
</div><!--end class [posts current-post]-->
<!-- end posts-->
</div><!--end col-sm-6-->


<!-- start right side-->

<?php echo $__env->make('posts.rightaside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- end right side section--> 
</div> <!--end body-->
</div><!--end center-->
</div><!--end contain-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>