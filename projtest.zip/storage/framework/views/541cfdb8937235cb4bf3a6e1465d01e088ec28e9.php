<form method="post" enctype="multipart/form-data">  
  <?php echo e(csrf_field()); ?>      
  <div class="upload" id="upload"> <!--upload div-->
    <div class="upload-selction">
    <input type="file" name="media" id="file" style="display: none;"/>
    <label for="file" style="cursor: pointer;">
    <i class="fa fa-photo" aria-hidden="true" style="cursor: pointer;"></i>
    <span>Add Photo Video</span>
    </label>     
    </div>

    <div class="upload-text form-group <?php echo e($errors->has('body') ? 'has-error' : ''); ?>">

    <textarea name="body" class="form-control" placeholder="Enter your post"></textarea>
    <?php if($errors->has('body')): ?>
    <small class="text-danger"><?php echo e($errors->first('body')); ?></small>
    <?php endif; ?>  
    </div>

    <div class="upload-selction">
    <select class="form-control" name="category">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    </div>
    <div class="upload-post">
    <input type="submit" value="Post">
    </div>
  </div><!--end upload div-->
</form><!--end form-->