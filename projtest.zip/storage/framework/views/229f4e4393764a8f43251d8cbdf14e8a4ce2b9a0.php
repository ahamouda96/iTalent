<?php $__env->startSection('content'); ?>
		
	<h1>Edit Post</h1>
	<div class="row">

		

		<div class="col-sm-9">
	
			<?php echo Form::model($post, ['method'=>'PATCH','action'=>['admin\AdminPostsController@update',$post->id],'files'=>true]); ?>

			    
			<div class='form-group'>
		        <?php echo Form::label('media','media:'); ?>

		        <?php echo Form::file('media',null,['class'=>'form-control']); ?>

		    </div>
			<div class="form-group">
			<?php if($post->postMedia): ?>
				<?php if($post->postMedia->type=="image"): ?>
				<img src="/uploads/posts/images/<?php echo e($post->postMedia->path); ?>" style='width:250px;height:250px;'>
				<?php endif; ?>
				<?php if($post->postMedia->type=="video"): ?>
				<video width="320" height="240" controls>
					<source src="/uploads/posts/video/<?php echo e($post->postMedia->path); ?>" controls style='width:250px;height:250px;'>
				</video>
				<!-- <video src="/uploads/posts/video/<?php echo e($post->postMedia->path); ?>" controls style='width:250px;height:250px;'> -->
				<?php endif; ?>
			<?php endif; ?>
			
			</div>
			
			<div class='form-group'>
		        <?php echo Form::label('body','Body:'); ?>

		        <?php echo Form::textarea('body',null,['class'=>'form-control', 'rows'=>5]); ?>

		    </div>
			    <div class='form-group'>
			        <?php echo Form::label('category_id','Category:'); ?>

			        <?php echo Form::select('category_id',$categories,null,['class'=>'form-control']); ?>

			    </div>
				
				

			    
			
			

			
			

			    <div class='form-group'>
			        <?php echo Form::submit('Update Post',['class'=>'btn btn-primary col-sm-6']); ?>

			    </div>

			<?php echo Form::close(); ?>


			
		</div>

	</div>

	<div class="row">

		<?php echo $__env->make('includes.form_error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>