<?php $__env->startSection('content'); ?>
	
	<?php if(Session::has('deleted_category')): ?>
		
		<p class="bg-danger"><?php echo e('\''.session('deleted_category').'\''.' has been deleted.'); ?></p>
	<?php endif; ?>

	<h1>Categories</h1>

	<div class="col-sm-3">
		
		<?php echo Form::open(['method'=>'POST','action'=>'admin\AdminCategoriesController@store']); ?>

		    <div class='form-group'>
		        <?php echo Form::label('name','Name:'); ?>

		        <?php echo Form::text('name',null,['class'=>'form-control']); ?>

		    </div>

		    <div class='form-group'>
		        <?php echo Form::submit('Create Category',['class'=>'btn btn-primary']); ?>

		    </div>

		<?php echo Form::close(); ?>


	</div>	

	<div class="col-sm-9">
		
		<table class="table">
		  <thead>
		    <tr>
		      <th>Id</th>
		      <th>Name</th>
		      <th>Created</th>
		      <th>Updated</th>
					<th>Edit</th>
		      <th>Delete</th>
		    </tr>
		  </thead>
		  <tbody>

		  <?php if($categories): ?>
		  	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  	<tr>
			  		<td><?php echo e($category->id); ?></td>
			  		<td><a href="<?php echo e(route('category.showAll',$category->name)); ?>"><?php echo e($category->name); ?></a></td>
			  		<td><?php echo e($category->created_at); ?></td>
			  		<td><?php echo e($category->updated_at->diffForHumans()); ?></td>
						<td>
							<a href="<?php echo e(route('categories.edit',$category->id)); ?>" class="btn btn-success" style="text-decoration:none; color:#fff ">Edit</a>
						</td>
						<td>
							<?php echo Form::open(['method'=>'DELETE','action'=>['admin\AdminCategoriesController@destroy',$category->id]]); ?>

							<?php echo Form::submit('Delete',['class'=>'btn btn-danger']); ?>

							<?php echo Form::close(); ?>

						</td>
			    </tr>
		  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  <?php endif; ?>
		  </tbody>
		</table>
	</div>
 
	<div class="row">
		<div class="col-sm-6 col-sm-offset-5">
				<?php echo e($categories->render()); ?>

		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>