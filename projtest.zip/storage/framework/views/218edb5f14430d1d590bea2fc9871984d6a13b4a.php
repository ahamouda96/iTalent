<!--comments section-->
<?php if(Auth::check()): ?>
<div class="panel panel-default" style="margin: 0; border-radius: 0;">
<div class="panel-body">
<form action="<?php echo e(url('/comment')); ?>" method="POST" style="display: flex;">
<?php echo e(csrf_field()); ?>

<input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
<input type="text" name="comment" placeholder="Enter your Comment" class="form-control" style="border-radius: 0;">
<input type="submit" value="Comment" class="btn btn-primary" style="border-radius: 0;">
</form>
<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
<a href="#" class="close" data-dismiss="alert">&times;</a>
<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($error); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>

<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="panel panel-default" style="margin: 10px; border-radius: 0;">
<div class="panel-body">
<div class="col-sm-9">
<?php echo e($comment->comment); ?> 
</div>
<div class="col-sm-3 text-right">
<a href="<?php echo e(route('front.profile', ['id' => $comment->user->id])); ?>" style="text-decoration: none; color: #666">
<?php echo e($comment->user->name); ?>

</a>
</div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php endif; ?>
</div> 