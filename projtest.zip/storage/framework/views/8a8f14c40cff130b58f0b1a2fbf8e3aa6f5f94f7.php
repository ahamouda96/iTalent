<?php $__env->startSection('content'); ?>
	<h1>Edit User</h1>
	
    <div class="row">

		<div class="col-sm-3">
			
			<img src="/uploads/images/<?php echo e($user->profile_image ? $user->profile_image : 'default.png'); ?>" style="width:250px; height:250px;" alt="user image" class="img-responsive img-rounded">

		</div>

		<div class="col-sm-9">
		<!-- laravelcollective/html -->
		<?php echo Form::model($user, ['method'=>'PATCH','action'=>['admin\AdminUsersController@update', $user->id],'files'=>true]); ?> 

			<div class='form-group'>
				<?php echo Form::label('name','Name:'); ?>

				<?php echo Form::text('name',null,['class'=>'form-control']); ?>

			</div>

			<div class='form-group'>
				<?php echo Form::label('email','Email:'); ?>

				<?php echo Form::text('email',null,['class'=>'form-control']); ?>

			</div>

			<div class='form-group'>
				<?php echo Form::label('password','Password:'); ?>

				<?php echo Form::password('password', ['class'=>'form-control']); ?>

			</div>

			<div class='form-group'>
				<?php echo Form::label('role_id','Role:'); ?>

				<?php echo Form::select('role_id',[''=>'Choose Options']+ $roles ,null, ['class'=>'form-control']); ?>

			</div>

			<div class='form-group'>
		    <?php echo Form::label('profile_image','Choose Image:'); ?>

		    <?php echo Form::file('profile_image', null, ['class'=>'form-control']); ?>

		</div> 

			<div class="form-group">
			<?php echo Form::submit('Update user', ['class' => 'btn btn-primary']); ?>

			</div>

			<?php echo Form::close(); ?>


			<!-- delete user form -->
			<!-- <?php echo Form::open(['method'=>'DELETE','action'=>['admin\AdminUsersController@destroy',$user->id] ]); ?>

			    <div class='form-group'>
			        <?php echo Form::submit('Delete User',['class'=>'btn btn-danger']); ?>

			    </div> -->

			<!-- <?php echo Form::close(); ?> -->
		

		</div>
	</div>
	<div class="row">	
		<?php echo $__env->make('includes.form_error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>