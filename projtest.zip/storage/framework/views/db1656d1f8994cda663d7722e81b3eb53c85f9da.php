<nav class="nav-container">
            
            <div class="navbar">
                <div class="logo">
                    <img src="/assets/images/LOGO.png" width="45px" height="45px">
                </div>
                <div class="nav-form">
                    <form>
                        <input type="text" placeholder="Search here people or pages...">
                        
                    </form>
                </div>
                
                <div class="notifcation">
                    <a href="home.html">
                        <i class="fa fa-home"></i>
                    </a>
                </div>
                
                <div class="notifcation">
                    <a href="#">
                    <i class="fa fa-globe"></i>
                        </a>
                </div>
                
                <div class="notifcation">
								<a href="comptation.html">
                              <i class='fas fa-medal' style='font-size:24px'></i>
                                </a>
						  </div>
                
                <div class="profile-info">
                    <div class="nav-profile-imge">
                        <a href=""><img src="/assets/images/PU2.png" alt="Oops"></a>
                    </div>
                    <div class="nav-profile-name">
                        
                        <ul class="my-dropdown">
                            <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>
                            <?php else: ?>
                            <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="margin-top: 2px">Name of T</a>
                              <ul class="dropdown-menu">
                                <li><a href="I%20talent(normal%20page%20for%20all).html">Profile</a></li>
                                <li id="setting-button"><span>Edit profile</span></li>
                                <li><a href="../Login/Login_v6/index.html">Log out</a></li>
                              </ul>
                            </li>
                            <?php endif; ?>
                        </ul>
                       
                    </div>
                </div>
            </div>
        </nav>