    <?php $__env->startSection('content'); ?>  
        <nav class="nav-container"> 
            <div class="navbar">
                <div class="logo">
                        <img src="images/LOGO.png" width="45px" height="45px">
                    </div>
                <div class="nav-form">
                    <form>
                        <input type="text" placeholder="Search here people or pages...">
                    </form>
                </div>
                
                <div class="notifcation">
                    <a href="home.html">
                        <i class="fa fa-home"></i>
                    </a>
                </div>
                
                <div class="notifcation">
                    <a href="#">
                    <i class="fa fa-globe"></i>
                        </a>
                </div>
                
                <div class="notifcation">
                                <a href="comptation.html">
                            <i class='fas fa-medal' style='font-size:24px'></i>
                                </a>
                        </div>
                
                <div class="profile-info">
                    <div class="nav-profile-imge">
                        <a href="I%20talent(normal%20page%20for%20all).html"><img src="images/PU2.png" alt="Oops"></a>
                    </div>
                    <div class="nav-profile-name">
                        <ul class="my-dropdown">
                            <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="margin-top: 2px">Name of T</a>
                            <ul class="dropdown-menu">
                                <li><a href="I%20talent(normal%20page%20for%20all).html">Profile</a></li>
                                <li id="setting-button"><span>Edit profile</span></li>
                                <li><a href="../Login/Login_v6/index.html">Log out</a></li>
                            </ul>
                            </li>
                        </ul>
                    
                    </div>
                </div>
            </div>
        </nav>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>