<?php $__env->startSection('content'); ?>
	<h1>Create User</h1>
	
    
    <!-- laravelcollective/html -->
	<?php echo Form::open(['method'=>'POST','action'=>'admin\AdminUsersController@store','files'=>true]); ?> 

		<div class='form-group'>
		    <?php echo Form::label('name','Name:'); ?>

		    <?php echo Form::text('name',null,['class'=>'form-control']); ?>

		</div>

		<div class='form-group'>
		    <?php echo Form::label('email','Email:'); ?>

		    <?php echo Form::text('email',null,['class'=>'form-control']); ?>

		</div>

		<div class='form-group'>
		    <?php echo Form::label('password','Password:'); ?>

		    <?php echo Form::password('password', ['class'=>'form-control']); ?>

		</div>

		<div class='form-group'>
		    <?php echo Form::label('role_id','Role:'); ?>

		    <?php echo Form::select('role_id',[''=>'Choose Options']+ $roles ,null, ['class'=>'form-control']); ?>

		</div>

		 <div class='form-group'>
		    <?php echo Form::label('profile_image','Choose Image:'); ?>

		    <?php echo Form::file('profile_image', null, ['class'=>'form-control']); ?>

		</div> 

		<div class="form-group">
		<?php echo Form::submit('Create user', ['class' => 'btn btn-primary']); ?>

		</div>
    
	<?php echo Form::close(); ?>


	<div class="row">	
		<?php echo $__env->make('includes.form_error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>