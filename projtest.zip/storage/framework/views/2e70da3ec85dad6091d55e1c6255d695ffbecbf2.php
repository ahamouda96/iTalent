<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-sm-12" >
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3 text-center" style="padding: 5px;">
                    <div style="box-shadow: 0 0 10px 1px grey; padding: 20px;">
                        <img src="/uploads/images/<?php echo e($user->profile_image); ?>" alt="Profile Picture" width="50" height="50">
                        <?php echo e($user->name); ?><br />
                        <a href="<?php echo e(route('user.show', $user->id)); ?>" style="color: #f00;">
                          View User
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-12">
                <?php echo e($users->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>