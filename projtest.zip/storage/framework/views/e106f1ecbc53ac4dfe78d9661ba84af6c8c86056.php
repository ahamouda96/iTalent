<?php $__env->startSection('content'); ?>
    <table class="table">
	  <thead>
	    <tr>
	      <th>Id</th>
	      <th>Owner</th>
	      <th>Category</th>
	      <th>Body</th>
	      <th>Post</th>
	      <!-- <th>Comments</th> -->
	      <th>Created</th>
	      <th>Updated</th>
				<th>Edit</th>
	      <th>Delete</th>
	    </tr>
	  </thead>
	  <tbody>
    
    <?php if($posts): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($post->id); ?></td>
								<!-- <td><img height="50" src="<?php echo e($post->photo ? $post->photo->file : '/images/default.png'); ?>" alt=""></td> -->
                <td><?php echo e($post->user ? $post->user->name : ''); ?></td>
                <td><?php echo e($post->category? $post->category->name : 'uncategoeized'); ?></td>
								<td><?php echo e(str_limit($post->body,9)); ?></td>
								<td><a href="<?php echo e(route('posts.edit',$post->id)); ?>">View Post</a></td>
								<!-- <td><a href="<?php echo e(route('comments.show',$post->id)); ?>">View Comments</a></td> -->
								<td><?php echo e($post->created_at->diffForHumans()); ?></td>
								<td><?php echo e($post->updated_at->diffForHumans()); ?></td>
								<td>
									<a href="<?php echo e(route('posts.edit',$post->id)); ?>" class="btn btn-success" style="text-decoration:none; color:#fff ">Edit</a>
								</td>
								<td>
									<?php echo Form::open(['method'=>'DELETE','action'=>['admin\AdminPostsController@destroy',$post->id]]); ?>

									<?php echo Form::submit('Delete',['class'=>'btn btn-danger']); ?>

									<?php echo Form::close(); ?>

								</td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
        </tbody>
	</table>
	<div class="row">
		<div class="col-sm-6 col-sm-offset-5">
				<?php echo e($posts->render()); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>