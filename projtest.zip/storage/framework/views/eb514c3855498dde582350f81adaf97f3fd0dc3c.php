<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-sm-12" style="margin-top: 68px;">
        <?php if($user->friends): ?>
            <?php $__currentLoopData = $user->friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3 text-center" style="padding: 5px;">
                    <div style="box-shadow: 0 0 10px 1px grey; padding: 20px;">
                    <img src="/uploads/images/<?php echo e($user_1->user2->profile_image); ?>" alt="Profile Picture" width="50" height="50">
                        <?php echo e($user_1->user2->username); ?><br />
                        <a href="<?php echo e(route('user.show', $user_1->user2->id)); ?>">View User</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php if($user->friends()->count() == 0): ?>
                <h1 class="text-center">This User does not have any friends</h1>
            <?php endif; ?>
        <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>