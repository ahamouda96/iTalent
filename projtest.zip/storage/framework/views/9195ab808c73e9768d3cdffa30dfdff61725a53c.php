

<?php $__env->startSection('content'); ?>

	<h1 class="text-center">Opps, no page available...</h1>

<?php $__env->stopSection(); ?>
