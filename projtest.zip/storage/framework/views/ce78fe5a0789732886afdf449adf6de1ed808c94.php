<?php $__env->startPush('css'); ?>
<style>
        .favorite_posts{
            color: red;
        }
        .followings{
            color: #E0245E;
        }
    </style>
    <?php $__env->stopPush(); ?>
<!-- start right side-->
<div class="col-sm-3">
<div class="aside-right">
<div class="top-post" style="height: 385px !important;">
<div class="Fimage">
<div class="title">
<span class="title-name">Friend Suggestion</span>

<ul class="my-dropdown">
<li class="dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
<span class="title-icon">
<span></span>
<span></span>
<span></span>
</span>
</a>
<ul class="dropdown-menu dropdown-menu-right">
<li><a href="#">Edit</a></li>
</ul>
</li>
</ul>
</div>
<hr class="hr">
<div class="posts-photo-N">
<ul>

<table>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td>
<a href="<?php echo e(route('front.profile', ['id' => $user->id])); ?>">
<img src="/uploads/images/<?php echo e($user->profile_image); ?>" alt="profile user image">
</a>
</td>
<td>
<h5><a href="<?php echo e(route('front.profile', ['id' => $user->id])); ?>"><?php echo e($user->name); ?></a></h5>
</td>
<td>
<?php if(Auth()->user()->id != $user->id): ?>         
<?php if(Auth::check()): ?>
<!-- like here-->
<?php if(auth()->guard()->guest()): ?>
<a href="javascript:void(0);" onclick="('To follow user. You need to login first.','Info',{
closeButton: true,
progressBar: true,
})">
<i class="fa fa-add"></i>
<?php echo e($user->followers->count()); ?>

 
</a>
<?php else: ?>
<a href="javascript:void(0);" onclick="document.getElementById('follow-form-<?php echo e($user->id); ?>').submit();"
class="<?php echo e(!Auth::user()->followings->where('pivot.leader_id',$user->id)->count()  == 0 ? 'followings' : ''); ?>">
<?php if($user->followers->count() == 1): ?>
    <span class="followings">unfollow</span>
<?php else: ?>
    <span>follow</span>
<?php endif; ?>

</a>

<form id="follow-form-<?php echo e($user->id); ?>" method="POST" action="<?php echo e(route('user.follow',$user->id)); ?>" style="display: none;">
<?php echo csrf_field(); ?>
</form>
<?php endif; ?>
<?php endif; ?>
<?php endif; ?>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</ul>
</div>

</div>
</div>



<div class="top-post">
<div class="title">
<span class="title-name">Top Posts</span>

<ul class="my-dropdown">
<li class="dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
<span class="title-icon">
<span></span>
<span></span>
<span></span>
</span>
</a>
<ul class="dropdown-menu dropdown-menu-right">
<li><a href="#">Edit</a></li>
</ul>
</li>
</ul>

</div>
<hr class="hr">
<div class="posts-photo">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
</div>
</div>
</div><!--end aside right div-->
</div><!--end col-sm-3 div-->