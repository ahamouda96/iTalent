<?php $__env->startPush('css'); ?>
    <style>
        .favorite_posts{
            color: #E0245E;
        }
        .category-showall{
            margin-top: 5%;
        }
        .pull-right{
            margin-top: -40px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="category-showall container">
        <div class="col-sm-6 col-sm-offset-3">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="panel panel-default">
                  <div class="panel-heading">
                  <h3 class="panel-title">  
                <img src="/uploads/images/<?php echo e($post->user->profile_image); ?>" alt="user image" style="width:40px; height:40px;border-radius: 50%;">
                <a href="<?php echo e(route('front.profile', ['id'=>$post->user->id])); ?>" style="text-decoration: none; color: #666">
                <span style="margin-left: 5px; font-weight: 600"><?php echo e($post->user->name); ?></span> <br>
                </a> 
                <span style="margin-left: 45px;"><?php echo e($post->updated_at->diffForHumans()); ?></span> 
            </h3>
                  </div>
                  <div class="panel-body">
                    <?php echo e($post->body); ?> <br>
                    <?php if($post->postMedia): ?> 
                        <?php if($post->postMedia->type=="image"): ?>
                        <img src="/uploads/posts/images/<?php echo e($post->postMedia->path); ?>" style='width:100%;height:600px;'>
                        <?php endif; ?>
                        <?php if($post->postMedia->type=="video"): ?>
                        <video style='width:100%;height:600px;' controls>
                            <source src="/uploads/posts/video/<?php echo e($post->postMedia->path); ?>">
                        </video>
                        <?php endif; ?>
                        <br>
                        <a href="<?php echo e(route('category.showAll', [$post->category->name])); ?>" class="badge"><?php echo e($post->category->name); ?></a>                    
                    <?php endif; ?>
                  </div>
                  <div class="panel-footer" data-postid="<?php echo e($post->id); ?>">
              <?php if(Auth::check()): ?>
                      <?php
                          $i = Auth::user()->likes()->count();
                          $commentCount = $post->comments()->where('comment', '!=', null)->count();
                      ?>
            
                <!-- like here-->
                <?php if(auth()->guard()->guest()): ?>
                <a href="javascript:void(0);" onclick="('To add favorite list. You need to login first.','Info',{
                    closeButton: true,
                    progressBar: true,
                    })">
                <i class="fa fa-heart"></i>
                <?php echo e($post->favorite_to_users->count()); ?>

                </a>
                <?php else: ?>
                    <a href="javascript:void(0);" onclick="document.getElementById('favorite-form-<?php echo e($post->id); ?>').submit();"
                        class="<?php echo e(!Auth::user()->favorite_posts->where('pivot.post_id',$post->id)->count()  == 0 ? 'favorite_posts' : ''); ?>">
                        <i class="fa fa-heart"></i>
                        <?php echo e($post->favorite_to_users->count()); ?>

                    </a>

                    <form id="favorite-form-<?php echo e($post->id); ?>" method="POST" action="<?php echo e(route('post.favorite',$post->id)); ?>" style="display: none;">
                    <?php echo csrf_field(); ?>
                    </form>
                <?php endif; ?>
                <?php endif; ?>
                <!-- end like here-->
                  <a href="#" class="btn btn-link">Comment</a>
              </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>