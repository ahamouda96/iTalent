<?php $__env->startPush('css'); ?>
    <style>
        .favorite_posts{
            color: red;
        }
        .followings{
            color: #E0245E;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
               
<!-- Start Center -->
            
<div class="center">
    <div class="head">
        <div class="background-img">
            <img src="/images/BC.jpg" alt="cover image">
        </div>

        <div class="tool-par">
            <div class="profile-img">
                <img src="/uploads/images/<?php echo e($user->profile_image); ?>" alt="">
                <span class="name"><?php echo e($user->name); ?></span>
            </div>

            <!-- <div class="tool-par-links" data-friendid="<?php echo e($user->id); ?>">
            <?php if(Auth()->user()->id != $user->id): ?>
                <?php if(Auth::check()): ?>
                    <?php
                        $i = Auth::user()->friends()->count();
                        $c = 1;
                    ?>
                    <?php $__currentLoopData = Auth::user()->friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($user_1->user2->id == $user->id): ?>
                    <a href="#" class="margin-center  remove-friend">unfollow</a>
                    <?php break; ?>
                    <?php elseif($i == $c): ?>
                    <a href="#" class="margin-center btn btn-link friend">follow</a>
                    <?php endif; ?>
                    <?php
                        $c++;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($i == 0): ?>
                    <a href="#" class="margin-center btn btn-link friend">follow</a>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?> 
                <a href="<?php echo e(route('friend.show', $user->id)); ?>" class="margin-right btn btn-link">
                    View Friends
                </a>   
            </div> -->
                                           
            <div class="tool-par-links">
            <!-- <a href="<?php echo e(route('user.follow', $user->id)); ?>">Follow User</a>
            <a href="<?php echo e(route('user.unfollow', $user->id)); ?>">Unfollow User</a> -->


<?php if(Auth()->user()->id != $user->id): ?> <!-- check if auth user-->       
<?php if(Auth::check()): ?>
<!-- start follow here-->
<?php if(auth()->guard()->guest()): ?>
<a href="javascript:void(0);" onclick="('To follow user. You need to login first.','Info',{
closeButton: true,
progressBar: true,
})">
<i class="fa fa-add"></i>
<?php echo e($user->followers->count()); ?>

 follow
</a>
<?php else: ?>
<a href="javascript:void(0);" onclick="document.getElementById('follow-form-<?php echo e($user->id); ?>').submit();"
class="<?php echo e(!Auth::user()->followings->where('pivot.leader_id',$user->id)->count()  == 0 ? 'followings' : ''); ?>">

<?php if($user->followers->count() == 1): ?>
    <span class="followings">unfollow</span>

<?php else: ?>
    <span>follow</span>

<?php endif; ?>
</a>


<form id="follow-form-<?php echo e($user->id); ?>" method="POST" action="<?php echo e(route('user.follow',$user->id)); ?>" style="display: none;">
<?php echo csrf_field(); ?>
</form>
<?php endif; ?>
<?php endif; ?>

<?php endif; ?> <!-- end if auth check-->
<!-- end follow here-->


            </div>
        </div>
   </div>
            
<div class="body">

<!-- End Aside Left -->
<div class="col-sm-3">
<div class="aside-left">
<div class="profile-intro">
<div class="title">
    <span class="title-name">Profile intro</span>
</div>
<hr class="hr">

<div class="items">
<p class="items-title">About Me:</p>
<span class="items-info">
<?php echo e($user->bio); ?>

</span>
</div>
<div class="items">
<p class="items-title">Favourite:</p>
<span class="items-info">
<?php echo e($user->bio); ?>

</span>
</div>

<div class="items">
<p class="items-title">Other Network:</p>
<a class="facebook" href="<?php echo e($user->links); ?>">
<i class="fa fa-facebook"></i>
</a>

</div>

<hr class="hr">
<div class="items-play">
<p><span> &copy;  2019 ITalent About Us Help
Terms Privacy policy
Marketing Bussiness Developers</span> </p>

<a href="https://play.google.com/store?hl=ar">
<button style='font-size:24px'>Google Play <i class='fab fa-google-play'></i></button>
</a>
</div>
</div>

</div>

</div>
<!-- End Aside Left -->
                    
<!-- Start Section Posts -->
<div class="col-sm-6">
<div class="posts">                      
<div class="create-poste-content">
<div class="upload">
<div class="upload-selction">
<div>
<i class="fa fa-photo"></i>
<span>Add Photo / Video</span>
</div>
<i class="fa fa-times close-create-post"></i>
</div>
<div class="upload-text">
<img src="/images/PU2.png" alt="Oops">
<form>
<textarea placeholder="What's on your mind?" id="text1" autofocus></textarea>
<div class="validation">
<div class="validation-box">
    <span>The Post is empty</span>
</div>
</div>
</form>
</div>
<div class="upload-post">
<form>
<input type="button" value="Post"  id="uplod-button">
</form>
</div>
</div>
</div>
<!-- End Create Poste -->

<!-- create post-->
<div class="upload" id="upload">
    <form method="post" enctype="multipart/form-data">
        <div class="upload-selction">
            <input type="file" name="media" id="file" style="display: none;"/>
            <i class="fa fa-photo" style="cursor: pointer;"></i>
            <span>Add Photo / Video</span>
        </div>
        <div class="upload-text form-group <?php echo e($errors->has('body') ? 'has-error' : ''); ?>">
            <img src="/uploads/images/<?php echo e(Auth::user()->profile_image); ?>" alt="profile image">
            <form>
            <textarea name="body" placeholder="What's on your mind?" id="open-create"></textarea>
            </form>
            <?php if($errors->has('body')): ?>
            <small class="text-danger"><?php echo e($errors->first('body')); ?></small>
            <?php endif; ?> 
        </div>
        <div class="upload-post">
            <select class="form-control" name="category">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>
        <div class="upload-post">
            <form>
                <input type="submit" value="Post">
            </form>
        </div>
    </form>
</div>  

<!--dispaly posts-->
<?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="post">
<div class="post-icon">
<?php if(Auth::check()): ?>
    <?php
    $i = Auth::user()->likes()->count();
    $commentCount = $post->comments()->where('comment', '!=', null)->count();
    ?>
    
   <!-- like here-->
            <?php if(auth()->guard()->guest()): ?>
                <a href="javascript:void(0);" onclick="('To add favorite list. You need to login first.','Info',{
                    closeButton: true,
                    progressBar: true,
                    })">
                <i class="fa fa-heart"></i>
                <?php echo e($post->favorite_to_users->count()); ?>

                </a>
                <?php else: ?>
                    <a href="javascript:void(0);" onclick="document.getElementById('favorite-form-<?php echo e($post->id); ?>').submit();"
                        class="<?php echo e(!Auth::user()->favorite_posts->where('pivot.post_id',$post->id)->count()  == 0 ? 'favorite_posts' : ''); ?>">
                        <i class="fa fa-heart"></i>
                        <?php echo e($post->favorite_to_users->count()); ?>

                    </a>

                    <form id="favorite-form-<?php echo e($post->id); ?>" method="POST" action="<?php echo e(route('post.favorite',$post->id)); ?>" style="display: none;">
                    <?php echo csrf_field(); ?>
                    </form>
                    <?php endif; ?>
                <!-- end like here-->
                <?php endif; ?>
    <i class="fa fa-comment"></i><h5><?php echo e($commentCount); ?></h5>
</div>


<div class="post-head">
<div class="post-info">
<img src="/images/PU2.png" alt="Oops">
<div class="post-info-name">
<span class="name"><?php echo e($user->name); ?></span>
<span class="time"><?php echo e($post->updated_at->diffForHumans()); ?></span>
</div>
</div>

<ul class="my-dropdown">
<li class="dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
<span class="title-icon">
    <span></span>
    <span></span>
    <span></span>
</span>
</a>
<!-- dropdown menu posts-->
<ul class="dropdown-menu dropdown-menu-right">
    <li><a href="<?php echo e(route('post.show', [$post->id])); ?>">Show Post</a></li>
    <li>
        <a href="<?php echo e(route('post.edit', [$post->id])); ?>">Edit Post</a>
    </li>
    <li>
        <a href="#" onclick="document.getElementById('delete').submit()">Delete Post</a>
        <?php echo Form::open(['method' => 'DELETE', 'id' => 'delete', 'route' => ['post.delete', $post->id]]); ?>

        <?php echo Form::close(); ?>

    </li>
</ul>
<!-- dropdown menu posts-->
</li>
</ul>
</div>
<!-- post content-->
<div class="post-content">
<p><?php echo e($post->body); ?></p>
<?php if($post->postMedia): ?>
    <?php if($post->postMedia->type=="image"): ?>
    <img src="/uploads/posts/images/<?php echo e($post->postMedia->path); ?>" style='width:100%;height:600px;'>
    <?php endif; ?>
    <?php if($post->postMedia->type=="video"): ?>
    <video style='width:100%;height:600px;' controls>
        <source src="/uploads/posts/video/<?php echo e($post->postMedia->path); ?>">
    </video>
    <?php endif; ?>
<?php endif; ?>
</div>
<!-- post content-->

<!-- post interacts-->
<div class="post-icon">
    <?php
    $i = Auth::user()->likes()->count();
    $commentCount = $post->comments()->where('comment', '!=', null)->count();
    ?>
    
    <!-- like here-->
    <?php if(auth()->guard()->guest()): ?>
<a href="javascript:void(0);" onclick="('To add favorite list. You need to login first.','Info',{
    closeButton: true,
    progressBar: true,
    })">
  <i class="fa fa-heart"></i>
  <?php echo e($post->favorite_to_users->count()); ?>

</a>
<?php else: ?>
    <a href="javascript:void(0);" onclick="document.getElementById('favorite-form-<?php echo e($post->id); ?>').submit();"
        class="<?php echo e(!Auth::user()->favorite_posts->where('pivot.post_id',$post->id)->count()  == 0 ? 'favorite_posts' : ''); ?>">
        <i class="fa fa-heart"></i>
        <?php echo e($post->favorite_to_users->count()); ?>

      </a>

    <form id="favorite-form-<?php echo e($post->id); ?>" method="POST" action="<?php echo e(route('post.favorite',$post->id)); ?>" style="display: none;">
    <?php echo csrf_field(); ?>
    </form>
<?php endif; ?>
                <!-- end like here-->
    
    <i class="fa fa-comment"></i><h5><?php echo e($commentCount); ?></h5>
</div>
<!-- post interacts-->

<div class="post-footer">
    <a href="<?php echo e(route('category.showAll', [$post->category? $post->category->name : 'uncategoeized'])); ?>" class="badge"><?php echo e($post->category->name); ?></a>
</div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!--end display posts-->
</div>
</div>
<!-- End Posts -->


<div class="col-sm-3">
<div class="aside-right">

<div class="top-post">
    <div class="title">
    <span class="title-name">Latest Post</span>
    </div>

    <hr class="hr">
   





    
    </div>
</div>
</div>
</div>
              

<!-- <div class="col-sm-3">
<div class="top-post">
<div class="title">
<span class="title-name">Top Posts</span>

<ul class="my-dropdown">
<li class="dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
<span class="title-icon">
<span></span>
<span></span>
<span></span>
</span>
</a>
<ul class="dropdown-menu dropdown-menu-right">
<li><a href="#">Edit</a></li>
</ul>
</li>
</ul>

</div>
<hr class="hr">
<div class="posts-photo">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
<img src="images/PU2.png" alt="Oops">
</div>
</div>
</div>
 -->


</div>
</div>                
<?php $__env->stopSection(); ?>
        
            
        
        
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>