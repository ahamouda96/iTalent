<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-sm-6 col-sm-offset-3">
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <a href="#" class="close" data-dismiss="alert">&times;</a>
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
            <?php echo Form::model($post, ['method' => 'PUT', 'files' => true, 'route' => ['post.update', $post->id]]); ?>

                <div class="panel panel-default">
                    <div class="panel-body">
                        
                    <?php if($post->friends()->count() > 0): ?>
                            <small>
                                with
                                <?php $__currentLoopData = $post->friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($tag->user2->name); ?>,
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </small>
                        <?php endif; ?>
                        <div class="pull-right">
                            <a href="<?php echo e(url('/posts')); ?>">Return back</a>
                        </div>
                       
                        <div class="form-group <?php echo e($errors->has('body') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::textarea('body', null, ['class' => 'form-control', 'placeholder' => 'Enter your post body'])); ?>

                            <?php if($errors->has('body')): ?>
                                <small class="text-danger"><?php echo e($errors->first('body')); ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                          <input type="file" class="form-control" name="media">
                        </div>
                        <div class="form-group">
                          <select class="form-control" name="category">
                              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == $post->category_id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>

                        <div class="form-group">
                            <select class="form-control select2-class" name="tags[]" multiple>
                                <?php $__currentLoopData = Auth::user()->friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($friend->id); ?>"><?php echo e($friend->user2->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <input type="submit" value="Update" class="btn btn-primary btn-block">
                    </div>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>