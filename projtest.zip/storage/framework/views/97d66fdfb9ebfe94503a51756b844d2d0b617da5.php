<?php $__env->startSection('content'); ?>
<script src="<?php echo e(asset('js/custom.js')); ?>" defer></script>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">List of Users- ItSolutionStuff.com</div>


                <div class="card-body">
                    <div class="row pl-5">
                        <?php echo $__env->make('userList', ['users'=>$users], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>