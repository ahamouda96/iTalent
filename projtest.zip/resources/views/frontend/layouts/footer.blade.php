<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    
    
    <script src="'js/main.js"></script>
    <script src="js/app.js"></script>
    <script src="js/vendor.js"></script>
    <script src="js/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugin.js"></script>
    <script src="js/custom.js"></script>
    </body> 
</html> 

       