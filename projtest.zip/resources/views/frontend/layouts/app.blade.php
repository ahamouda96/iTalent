
@include('frontend.layouts.header');

<div class="contant">
	<div class="center">
		<div class="body">
			 @yield('content')
		</div>
	</div>
</div>
@include('frontend.layouts.footer')